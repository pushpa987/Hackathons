from flask import Flask, render_template, request, send_from_directory
import cv2
import mediapipe as mp
import os

app = Flask(__name__)

mp_pose = mp.solutions.pose
pose = mp_pose.Pose()

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'mp4'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def detect_and_draw_pose_webcam():
    # Open webcam
    cap = cv2.VideoCapture(0) # 0 for webcam
    
    # Initialize MediaPipe Pose model
    pose = mp.solutions.pose.Pose()
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        # Convert the BGR image to RGB
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Process the image and get the poses
        results = pose.process(frame_rgb)
        
        # Draw the poses on the frame
        if results.pose_landmarks:
            mp.solutions.drawing_utils.draw_landmarks(frame, results.pose_landmarks, mp.solutions.pose.POSE_CONNECTIONS)
        
        cv2.imshow('Pose Detection', frame)
        if cv2.waitKey(1) & 0xFF == ord('s'):
            break

    cap.release()
    cv2.destroyAllWindows()

def detect_and_draw_pose_in_video(video_path):
    # Initialize MediaPipe Pose model
    mp_pose = mp.solutions.pose
    pose = mp_pose.Pose()

    # Using Video
    video = cv2.VideoCapture(video_path)
    while video.isOpened():
        ret, frame = video.read()
        if not ret:
            break
        
        # Convert the BGR image to RGB
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Process the image and get the poses
        results = pose.process(frame_rgb)
        
        # Draw the poses on the frame
        if results.pose_landmarks:
            mp.solutions.drawing_utils.draw_landmarks(frame, results.pose_landmarks, mp_pose.POSE_CONNECTIONS)
        
        cv2.imshow('Pose Detection', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            print("bye")
            break

    video.release()
    cv2.destroyAllWindows()

def detect_and_draw_pose_in_image(image_path):
    image = cv2.imread(image_path)
    if image is None:
        return None
    
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    results = pose.process(image_rgb)
    
    if results.pose_landmarks:
        # Draw lines between pose landmarks
        mp.solutions.drawing_utils.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                                  mp.solutions.drawing_utils.DrawingSpec(color=(0, 255, 0), thickness=2, circle_radius=2),
                                                  mp.solutions.drawing_utils.DrawingSpec(color=(255, 0, 0), thickness=2, circle_radius=2))
    
    output_image_path = os.path.join(app.config['UPLOAD_FOLDER'], 'output_' + os.path.basename(image_path))
    cv2.imwrite(output_image_path, image)
    return output_image_path

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('home.html')

@app.route('/input')
def input():
    return render_template('inputpage.html')
@app.route('/about')
def about():
    return render_template('about.html')
@app.route('/home')
def home():
    return render_template('home.html')
@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return "No file part"
    
    file = request.files['file']
    
    if file.filename == '':
        out_webcam=detect_and_draw_pose_webcam()
        return render_template('result.html',image=out_webcam)
    
    if file and allowed_file(file.filename):
        filename = file.filename
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        
        if filename.endswith(('png', 'jpg', 'jpeg')):
            output_image_path = detect_and_draw_pose_in_image(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            if output_image_path:
                rel_output_image_path = os.path.relpath(output_image_path, app.config['UPLOAD_FOLDER'])
                return render_template('result.html', image=rel_output_image_path)
        elif filename.endswith(('mp4')):
            output_video_path = detect_and_draw_pose_in_video(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            if output_video_path:
                rel_output_video_path = os.path.relpath(output_video_path, app.config['UPLOAD_FOLDER'])
                return render_template('result.html', video=rel_output_video_path)

    return "REACHED END POINT OF THE VIDEO"
    

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)
    app.run(debug=True)
